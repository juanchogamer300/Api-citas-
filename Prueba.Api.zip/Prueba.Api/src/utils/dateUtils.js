const { DateTime } = require('luxon');
const { BadRequestError } = require('./errors');

/**
 * Valida y parsea una cadena en formato ISO 8601.
 * @param {string} isoString
 * @param {string} fieldName
 * @returns {DateTime}
 */
function parseAndValidateIso(isoString, fieldName = 'fechaHora') {
  if (typeof isoString !== 'string' || !isoString.trim()) {
    throw new BadRequestError(`El campo '${fieldName}' es obligatorio y debe ser una cadena ISO 8601 válida.`);
  }

  // Regex para formato ISO 8601 con fecha y hora completa
  const isoPattern = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:?\d{2})?$/;
  if (!isoPattern.test(isoString.trim())) {
    throw new BadRequestError(`El campo '${fieldName}' no cumple con el formato estándar ISO 8601 (ej. '2026-11-10T10:00:00-05:00' o '2026-11-10T15:00:00Z').`);
  }

  const dt = DateTime.fromISO(isoString.trim(), { setZone: true });
  if (!dt.isValid) {
    throw new BadRequestError(`El campo '${fieldName}' contiene una fecha u hora inválida: ${dt.invalidExplanation || 'valor fuera de rango'}.`);
  }

  return dt;
}

/**
 * Normaliza un objeto DateTime a cadena ISO 8601 en UTC.
 * @param {DateTime} dt
 * @returns {string} Ejemplo: "2026-11-10T15:00:00.000Z"
 */
function toUtcIso(dt) {
  return dt.toUTC().toISO({ suppressMilliseconds: false });
}

/**
 * Comprueba si un DateTime corresponde a un instante en el pasado respecto al momento actual.
 * @param {DateTime} dt
 * @returns {boolean}
 */
function isPast(dt) {
  return dt.toMillis() < DateTime.now().toMillis();
}

/**
 * Valida una fecha en formato estricto YYYY-MM-DD.
 * @param {string} dateStr
 * @returns {boolean}
 */
function parseDateParam(dateStr) {
  if (typeof dateStr !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(dateStr.trim())) {
    throw new BadRequestError("El parámetro 'fecha' es obligatorio y debe tener el formato YYYY-MM-DD.");
  }

  const dt = DateTime.fromISO(dateStr.trim(), { zone: 'UTC' });
  if (!dt.isValid) {
    throw new BadRequestError(`La fecha '${dateStr}' no es una fecha real válida del calendario.`);
  }

  return dt;
}

/**
 * Normaliza la lista de días de atención.
 * Admite formatos como "1,2,3,4,5" o array [1,2,3,4,5].
 * Soporta tanto convención ISO (1=Lunes .. 7=Domingo) como convención JS (0=Domingo).
 * @param {string|number[]} dias
 * @returns {number[]} Días normalizados en convención ISO (1=Lunes .. 7=Domingo)
 */
function normalizeDaysOfWeek(dias) {
  let list = [];
  if (Array.isArray(dias)) {
    list = dias;
  } else if (typeof dias === 'string') {
    try {
      const parsed = JSON.parse(dias);
      if (Array.isArray(parsed)) list = parsed;
      else list = dias.split(',').map((s) => parseInt(s.trim(), 10));
    } catch {
      list = dias.split(',').map((s) => parseInt(s.trim(), 10));
    }
  }

  return list.map((d) => (d === 0 ? 7 : d));
}

/**
 * Valida si un intervalo de reserva está dentro de los días y horario de atención del proveedor.
 * @param {DateTime} inicioDt
 * @param {DateTime} finDt
 * @param {string} horaApertura "HH:MM"
 * @param {string} horaCierre "HH:MM"
 * @param {string|number[]} diasAtencion
 * @param {string} timezone
 */
function validateWithinSchedule(inicioDt, finDt, horaApertura, horaCierre, diasAtencion, timezone) {
  const inicioLocal = inicioDt.setZone(timezone);
  const finLocal = finDt.setZone(timezone);

  // Validar que comience y termine en el mismo día calendario local
  if (inicioLocal.toISODate() !== finLocal.toISODate()) {
    throw new BadRequestError('La reserva debe comenzar y finalizar dentro del mismo día laboral.');
  }

  // Validar día de la semana
  const diasPermitidos = normalizeDaysOfWeek(diasAtencion);
  const diaSemana = inicioLocal.weekday; // 1 = Lunes, 7 = Domingo

  if (!diasPermitidos.includes(diaSemana)) {
    const nombresDias = {
      1: 'Lunes',
      2: 'Martes',
      3: 'Miércoles',
      4: 'Jueves',
      5: 'Viernes',
      6: 'Sábado',
      7: 'Domingo'
    };
    const diaActualNombre = nombresDias[diaSemana] || `día ${diaSemana}`;
    throw new BadRequestError(`El proveedor no atiende en el día seleccionado (${diaActualNombre}).`);
  }

  // Validar horario de atención
  const horaInicioStr = inicioLocal.toFormat('HH:mm');
  const horaFinStr = finLocal.toFormat('HH:mm');

  if (horaInicioStr < horaApertura || horaFinStr > horaCierre) {
    throw new BadRequestError(
      `La reserva se encuentra fuera del horario de atención del proveedor (${horaApertura} a ${horaCierre} en zona horaria ${timezone}). Horario solicitado: ${horaInicioStr} a ${horaFinStr}.`
    );
  }

  if (horaFinStr <= horaInicioStr) {
    throw new BadRequestError('La hora de finalización debe ser posterior a la hora de inicio.');
  }
}

/**
 * Genera intervalos de tiempo candidatos para un día y horario determinado.
 * @param {string} dateStr YYYY-MM-DD
 * @param {string} horaApertura "HH:MM"
 * @param {string} horaCierre "HH:MM"
 * @param {number} duracionMinutos
 * @param {string} timezone
 * @returns {Array<{ inicio: DateTime, fin: DateTime }>}
 */
function generateSlotsForDay(dateStr, horaApertura, horaCierre, duracionMinutos, timezone) {
  const [aperturaH, aperturaM] = horaApertura.split(':').map(Number);
  const [cierreH, cierreM] = horaCierre.split(':').map(Number);

  let current = DateTime.fromObject(
    {
      year: parseInt(dateStr.slice(0, 4), 10),
      month: parseInt(dateStr.slice(5, 7), 10),
      day: parseInt(dateStr.slice(8, 10), 10),
      hour: aperturaH,
      minute: aperturaM,
      second: 0,
      millisecond: 0
    },
    { zone: timezone }
  );

  const cierreTime = DateTime.fromObject(
    {
      year: parseInt(dateStr.slice(0, 4), 10),
      month: parseInt(dateStr.slice(5, 7), 10),
      day: parseInt(dateStr.slice(8, 10), 10),
      hour: cierreH,
      minute: cierreM,
      second: 0,
      millisecond: 0
    },
    { zone: timezone }
  );

  const slots = [];
  while (true) {
    const next = current.plus({ minutes: duracionMinutos });
    if (next > cierreTime) {
      break;
    }
    slots.push({ inicio: current, fin: next });
    current = next;
  }

  return slots;
}

module.exports = {
  parseAndValidateIso,
  toUtcIso,
  isPast,
  parseDateParam,
  normalizeDaysOfWeek,
  validateWithinSchedule,
  generateSlotsForDay
};
