const fs = require('node:fs');
const path = require('node:path');
const Database = require('better-sqlite3');
const config = require('../config/env');

let defaultDbInstance = null;

/**
 * Crea o retorna una conexión a la base de datos SQLite.
 * Permite pasar una ruta personalizada o ':memory:' para pruebas.
 * @param {string} [customPath]
 * @returns {Database.Database}
 */
function getDatabase(customPath) {
  const targetPath = customPath || config.dbPath;

  // Si no se especifica ruta personalizada y ya tenemos una instancia singleton por defecto
  if (!customPath && defaultDbInstance) {
    return defaultDbInstance;
  }

  // Si es un archivo físico en disco, asegurar que el directorio padre exista
  if (targetPath !== ':memory:') {
    const dir = path.dirname(path.resolve(targetPath));
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }

  const db = new Database(targetPath);

  // Optimizaciones de rendimiento, consistencia e integridad referencial
  db.pragma('foreign_keys = ON');
  db.pragma('busy_timeout = 5000');
  if (targetPath !== ':memory:') {
    db.pragma('journal_mode = WAL');
  }

  if (!customPath) {
    defaultDbInstance = db;
  }

  return db;
}

/**
 * Cierra la conexión singleton por defecto si está abierta.
 */
function closeDatabase() {
  if (defaultDbInstance) {
    defaultDbInstance.close();
    defaultDbInstance = null;
  }
}

module.exports = {
  getDatabase,
  closeDatabase
};
