const { getDatabase } = require('../database/connection');

class ClienteRepository {
  constructor(db) {
    this.db = db || getDatabase();
  }

  findById(id) {
    const stmt = this.db.prepare('SELECT * FROM clientes WHERE id = ?');
    return stmt.get(id);
  }

  findByEmail(email) {
    const stmt = this.db.prepare('SELECT * FROM clientes WHERE email = ? COLLATE NOCASE');
    return stmt.get(email.trim());
  }

  findAll() {
    const stmt = this.db.prepare('SELECT * FROM clientes ORDER BY id ASC');
    return stmt.all();
  }

  create({ nombre, email, telefono }) {
    const stmt = this.db.prepare(`
      INSERT INTO clientes (nombre, email, telefono)
      VALUES (?, ?, ?)
    `);
    const info = stmt.run(nombre.trim(), email.trim().toLowerCase(), telefono ? telefono.trim() : null);
    return this.findById(info.lastInsertRowid);
  }

  update(id, { nombre, email, telefono }) {
    const stmt = this.db.prepare(`
      UPDATE clientes
      SET nombre = ?, email = ?, telefono = ?
      WHERE id = ?
    `);
    stmt.run(nombre.trim(), email.trim().toLowerCase(), telefono ? telefono.trim() : null, id);
    return this.findById(id);
  }

  delete(id) {
    const stmt = this.db.prepare('DELETE FROM clientes WHERE id = ?');
    const result = stmt.run(id);
    return result.changes > 0;
  }
}

module.exports = ClienteRepository;
