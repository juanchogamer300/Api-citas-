const { getDatabase } = require('../database/connection');
const { ScheduleConflictError } = require('../utils/errors');

class ReservaRepository {
  constructor(db) {
    this.db = db || getDatabase();
  }

  findById(id) {
    const stmt = this.db.prepare(`
      SELECT 
        r.id,
        r.clienteId,
        c.nombre AS clienteNombre,
        c.email AS clienteEmail,
        c.telefono AS clienteTelefono,
        r.proveedorId,
        p.nombre AS proveedorNombre,
        p.tipo AS proveedorTipo,
        r.fechaHoraInicio,
        r.fechaHoraFin,
        r.estado,
        r.createdAt
      FROM reservas r
      JOIN clientes c ON r.clienteId = c.id
      JOIN proveedores p ON r.proveedorId = p.id
      WHERE r.id = ?
    `);
    return stmt.get(id);
  }

  findAll({ clienteId, proveedorId, estado, fechaDesde, fechaHasta } = {}) {
    const conditions = [];
    const params = [];

    if (clienteId !== undefined && clienteId !== null) {
      conditions.push('r.clienteId = ?');
      params.push(clienteId);
    }

    if (proveedorId !== undefined && proveedorId !== null) {
      conditions.push('r.proveedorId = ?');
      params.push(proveedorId);
    }

    if (estado) {
      conditions.push('r.estado = ?');
      params.push(estado);
    }

    if (fechaDesde) {
      conditions.push('r.fechaHoraInicio >= ?');
      params.push(fechaDesde);
    }

    if (fechaHasta) {
      conditions.push('r.fechaHoraFin <= ?');
      params.push(fechaHasta);
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    const stmt = this.db.prepare(`
      SELECT 
        r.id,
        r.clienteId,
        c.nombre AS clienteNombre,
        c.email AS clienteEmail,
        c.telefono AS clienteTelefono,
        r.proveedorId,
        p.nombre AS proveedorNombre,
        p.tipo AS proveedorTipo,
        r.fechaHoraInicio,
        r.fechaHoraFin,
        r.estado,
        r.createdAt
      FROM reservas r
      JOIN clientes c ON r.clienteId = c.id
      JOIN proveedores p ON r.proveedorId = p.id
      ${whereClause}
      ORDER BY r.fechaHoraInicio ASC
    `);

    return stmt.all(...params);
  }

  /**
   * Obtiene las reservas confirmadas de un proveedor que se solapan con un rango de tiempo.
   * Utilizado para calcular la disponibilidad diaria.
   */
  findConfirmedOverlaps(proveedorId, rangoInicioUtc, rangoFinUtc) {
    const stmt = this.db.prepare(`
      SELECT id, fechaHoraInicio, fechaHoraFin
      FROM reservas
      WHERE proveedorId = ?
        AND estado = 'confirmada'
        AND fechaHoraInicio < ?
        AND fechaHoraFin > ?
      ORDER BY fechaHoraInicio ASC
    `);
    return stmt.all(proveedorId, rangoFinUtc, rangoInicioUtc);
  }

  /**
   * Crea una reserva dentro de una transacción atómica con BEGIN IMMEDIATE.
   * La comprobación del conflicto y la inserción se ejecutan de manera indivisible.
   * Si existe solapamiento con otra reserva confirmada, se lanza ScheduleConflictError.
   */
  createAtomic({ clienteId, proveedorId, fechaHoraInicio, fechaHoraFin }) {
    const checkStmt = this.db.prepare(`
      SELECT id
      FROM reservas
      WHERE proveedorId = ?
        AND estado = 'confirmada'
        AND fechaHoraInicio < ?
        AND fechaHoraFin > ?
      LIMIT 1
    `);

    const insertStmt = this.db.prepare(`
      INSERT INTO reservas (clienteId, proveedorId, fechaHoraInicio, fechaHoraFin, estado)
      VALUES (?, ?, ?, ?, 'confirmada')
    `);

    const getCreatedStmt = this.db.prepare(`
      SELECT 
        r.id,
        r.clienteId,
        c.nombre AS clienteNombre,
        c.email AS clienteEmail,
        c.telefono AS clienteTelefono,
        r.proveedorId,
        p.nombre AS proveedorNombre,
        p.tipo AS proveedorTipo,
        r.fechaHoraInicio,
        r.fechaHoraFin,
        r.estado,
        r.createdAt
      FROM reservas r
      JOIN clientes c ON r.clienteId = c.id
      JOIN proveedores p ON r.proveedorId = p.id
      WHERE r.id = ?
    `);

    const transaction = this.db.transaction((data) => {
      // 1. Comprobar solapamiento atómicamente
      // Regla: nuevaInicio < existenteFin && nuevaFin > existenteInicio
      const conflict = checkStmt.get(data.proveedorId, data.fechaHoraFin, data.fechaHoraInicio);
      if (conflict) {
        throw new ScheduleConflictError();
      }

      // 2. Insertar reserva confirmada
      const info = insertStmt.run(
        data.clienteId,
        data.proveedorId,
        data.fechaHoraInicio,
        data.fechaHoraFin
      );

      // 3. Retornar el registro completo
      return getCreatedStmt.get(info.lastInsertRowid);
    });

    // Iniciar transacción inmediata para adquirir el bloqueo de escritura inmediatamente
    return transaction.immediate({
      clienteId,
      proveedorId,
      fechaHoraInicio,
      fechaHoraFin
    });
  }

  /**
   * Cancela una reserva atómicamente.
   * Retorna:
   * - null si la reserva no existe
   * - { alreadyCancelled: true, reserva } si ya estaba cancelada
   * - { alreadyCancelled: false, reserva: updatedReserva } si se canceló exitosamente
   */
  cancelarAtomic(id) {
    const findStmt = this.db.prepare('SELECT id, estado FROM reservas WHERE id = ?');
    const updateStmt = this.db.prepare("UPDATE reservas SET estado = 'cancelada' WHERE id = ?");

    const transaction = this.db.transaction((reservaId) => {
      const existing = findStmt.get(reservaId);
      if (!existing) {
        return { notFound: true };
      }

      if (existing.estado === 'cancelada') {
        const fullRecord = this.findById(reservaId);
        return { alreadyCancelled: true, reserva: fullRecord };
      }

      updateStmt.run(reservaId);
      const updated = this.findById(reservaId);
      return { alreadyCancelled: false, reserva: updated };
    });

    return transaction.immediate(id);
  }

  delete(id) {
    const stmt = this.db.prepare('DELETE FROM reservas WHERE id = ?');
    const result = stmt.run(id);
    return result.changes > 0;
  }
}

module.exports = ReservaRepository;

