const ReservaService = require('../services/reservaService');
const {
  validateCreateReserva,
  validateReservaFilters,
  validateReservaId
} = require('../validators/reservaValidator');

class ReservaController {
  constructor(reservaService) {
    this.reservaService = reservaService || new ReservaService();
  }

  crearReserva = async (req, res, next) => {
    try {
      const datosValidados = validateCreateReserva(req.body);
      const nuevaReserva = this.reservaService.crearReserva(datosValidados);
      return res.status(201).json(nuevaReserva);
    } catch (error) {
      next(error);
    }
  };

  listarReservas = async (req, res, next) => {
    try {
      const filtros = validateReservaFilters(req.query);
      const reservas = this.reservaService.obtenerTodas(filtros);
      return res.status(200).json(reservas);
    } catch (error) {
      next(error);
    }
  };

  obtenerReservaPorId = async (req, res, next) => {
    try {
      const id = validateReservaId(req.params.id);
      const reserva = this.reservaService.obtenerPorId(id);
      return res.status(200).json(reserva);
    } catch (error) {
      next(error);
    }
  };

  cancelarReserva = async (req, res, next) => {
    try {
      const id = validateReservaId(req.params.id);
      const reservaCancelada = this.reservaService.cancelarReserva(id);
      return res.status(200).json(reservaCancelada);
    } catch (error) {
      next(error);
    }
  };

  eliminarReserva = async (req, res, next) => {
    try {
      const id = validateReservaId(req.params.id);
      const resultado = this.reservaService.eliminarReserva(id);
      return res.status(200).json(resultado);
    } catch (error) {
      next(error);
    }
  };
}

module.exports = ReservaController;

