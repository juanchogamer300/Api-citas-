const { AppError, ScheduleConflictError } = require('../utils/errors');

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  // 1. Caso crítico específico obligatorio: Conflicto de horario por solapamiento
  if (err instanceof ScheduleConflictError || err.isScheduleConflict) {
    return res.status(409).json({
      error: 'Conflicto de horario',
      detalle: 'El proveedor ya tiene una reserva en el intervalo solicitado.'
    });
  }

  // 2. Errores controlados de la aplicación (AppError, BadRequestError, NotFoundError, ConflictError)
  if (err instanceof AppError) {
    return res.status(err.statusCode).json({
      error: err.message,
      detalle: err.detalle
    });
  }

  // 3. Manejo de error de sintaxis en JSON (body-parser / express.json)
  if (err instanceof SyntaxError && err.status === 400 && 'body' in err) {
    return res.status(400).json({
      error: 'Solicitud inválida',
      detalle: 'El cuerpo de la solicitud no es un JSON válido o está mal formado.'
    });
  }

  // 4. Manejo de errores nativos de SQLite
  if (err.code === 'SQLITE_CONSTRAINT_UNIQUE') {
    return res.status(409).json({
      error: 'Conflicto de datos',
      detalle: 'Ya existe un registro con información duplicada en el sistema.'
    });
  }

  if (err.code === 'SQLITE_CONSTRAINT_FOREIGNKEY') {
    return res.status(400).json({
      error: 'Solicitud inválida',
      detalle: 'Referencia a un recurso inexistente en la base de datos.'
    });
  }

  // 5. Error interno no controlado (500) - No exponer trazas internas ni rutas locales
  // Se puede registrar en el logger interno del servidor sin exponerlo al cliente HTTP
  return res.status(500).json({
    error: 'Error interno del servidor',
    detalle: 'Ocurrió un error inesperado al procesar la solicitud.'
  });
}

module.exports = errorHandler;
