const { test, describe, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const request = require('supertest');
const Database = require('better-sqlite3');
const { createApp } = require('../src/app');

describe('Suite de Pruebas API REST - Sistema de Reservas y Turnos', () => {
  let db;
  let app;

  beforeEach(() => {
    // Base de datos SQLite aislada en memoria para cada prueba
    db = new Database(':memory:');
    db.pragma('foreign_keys = ON');
    app = createApp({ db, seed: true });
  });

  afterEach(() => {
    if (db) {
      db.close();
    }
  });

  // 1. Creación y consulta de clientes
  test('1. Creación y consulta de clientes', async () => {
    // Crear cliente
    const nuevoCliente = {
      nombre: 'Mariana Duque',
      email: 'mariana.duque@email.com',
      telefono: '+573109988776'
    };

    const resPost = await request(app)
      .post('/api/clientes')
      .send(nuevoCliente)
      .expect(201);

    assert.equal(resPost.body.nombre, nuevoCliente.nombre);
    assert.equal(resPost.body.email, nuevoCliente.email);
    assert.ok(resPost.body.id);

    // Evitar correo duplicado
    const resDup = await request(app)
      .post('/api/clientes')
      .send(nuevoCliente)
      .expect(409);

    assert.equal(resDup.body.error, 'Conflicto de datos');

    // Listar clientes
    const resList = await request(app).get('/api/clientes').expect(200);
    assert.ok(Array.isArray(resList.body));
    assert.ok(resList.body.length >= 4);

    // Consultar por ID
    const resGet = await request(app).get(`/api/clientes/${resPost.body.id}`).expect(200);
    assert.equal(resGet.body.id, resPost.body.id);
    assert.equal(resGet.body.email, nuevoCliente.email);
  });

  // 2. Listado de proveedores
  test('2. Listado de proveedores y detalle', async () => {
    const resList = await request(app).get('/api/proveedores').expect(200);
    assert.ok(Array.isArray(resList.body));
    assert.ok(resList.body.length >= 3);

    const primerProveedor = resList.body[0];
    assert.ok(primerProveedor.id);
    assert.ok(primerProveedor.nombre);
    assert.equal(primerProveedor.activo, 1);

    // Detalle existente
    const resDetalle = await request(app).get(`/api/proveedores/${primerProveedor.id}`).expect(200);
    assert.equal(resDetalle.body.id, primerProveedor.id);

    // Detalle no existente
    const resNotFound = await request(app).get('/api/proveedores/9999').expect(404);
    assert.equal(resNotFound.body.error, 'Recurso no encontrado');
  });

  // 3. Consulta de disponibilidad
  test('3. Consulta de disponibilidad de un proveedor', async () => {
    // 2026-11-10 es un martes (día laboral del proveedor 1, horario 08:00 a 17:00, 30 min)
    const fecha = '2026-11-10';
    const res = await request(app)
      .get(`/api/proveedores/1/disponibilidad?fecha=${fecha}`)
      .expect(200);

    assert.equal(res.body.fecha, fecha);
    assert.equal(res.body.proveedor.id, 1);
    assert.ok(Array.isArray(res.body.intervalosDisponibles));
    assert.ok(res.body.intervalosDisponibles.length > 0);

    const primerIntervalo = res.body.intervalosDisponibles[0];
    assert.ok(primerIntervalo.inicio);
    assert.ok(primerIntervalo.fin);
    assert.ok(primerIntervalo.inicioUtc);
    assert.ok(primerIntervalo.finUtc);

    // Validación de fecha inválida en query
    const resFechaInvalida = await request(app)
      .get('/api/proveedores/1/disponibilidad?fecha=2026-02-31')
      .expect(400);
    assert.equal(resFechaInvalida.body.error, 'Solicitud inválida');
  });

  // 4. Creación de una reserva válida
  test('4. Creación de una reserva válida', async () => {
    const reservaData = {
      clienteId: 1,
      proveedorId: 1,
      fechaHoraInicio: '2026-11-10T10:00:00-05:00',
      duracionMinutos: 30
    };

    const res = await request(app)
      .post('/api/reservas')
      .send(reservaData)
      .expect(201);

    assert.ok(res.body.id);
    assert.equal(res.body.clienteId, 1);
    assert.equal(res.body.proveedorId, 1);
    assert.equal(res.body.estado, 'confirmada');
    assert.ok(res.body.fechaHoraInicio);
    assert.ok(res.body.fechaHoraFin);
    // Verificar que fechaHoraFin sea 30 min posterior
    const inicioMs = new Date(res.body.fechaHoraInicio).getTime();
    const finMs = new Date(res.body.fechaHoraFin).getTime();
    assert.equal(finMs - inicioMs, 30 * 60 * 1000);
  });

  // 5. Intento de reservar un horario superpuesto y comprobación exacta del HTTP 409 y su JSON
  test('5. Intento de reservar un horario superpuesto y comprobación exacta del HTTP 409 y su JSON', async () => {
    // 1. Crear reserva inicial [10:00, 10:30)
    await request(app)
      .post('/api/reservas')
      .send({
        clienteId: 1,
        proveedorId: 1,
        fechaHoraInicio: '2026-11-10T10:00:00-05:00',
        duracionMinutos: 30
      })
      .expect(201);

    // 2. Intentar reserva solapada [10:15, 10:45)
    const resSolapada = await request(app)
      .post('/api/reservas')
      .send({
        clienteId: 2,
        proveedorId: 1,
        fechaHoraInicio: '2026-11-10T10:15:00-05:00',
        duracionMinutos: 30
      })
      .expect(409);

    // Verificación exacta del cuerpo JSON requerido sin campos adicionales
    assert.deepEqual(resSolapada.body, {
      error: 'Conflicto de horario',
      detalle: 'El proveedor ya tiene una reserva en el intervalo solicitado.'
    });
  });

  // 6. Reserva consecutiva sin solapamiento (permitida)
  test('6. Reserva consecutiva sin solapamiento (permitida: intervalo [inicio, fin))', async () => {
    // Reserva 1: [10:00, 10:30)
    const res1 = await request(app)
      .post('/api/reservas')
      .send({
        clienteId: 1,
        proveedorId: 1,
        fechaHoraInicio: '2026-11-10T10:00:00-05:00',
        duracionMinutos: 30
      })
      .expect(201);

    // Reserva 2: [10:30, 11:00) exactamente consecutiva
    const res2 = await request(app)
      .post('/api/reservas')
      .send({
        clienteId: 2,
        proveedorId: 1,
        fechaHoraInicio: '2026-11-10T10:30:00-05:00',
        duracionMinutos: 30
      })
      .expect(201);

    assert.ok(res1.body.id);
    assert.ok(res2.body.id);
    assert.equal(res1.body.fechaHoraFin, res2.body.fechaHoraInicio);
  });

  // 7. Reserva con un cliente inexistente
  test('7. Reserva con un cliente inexistente', async () => {
    const res = await request(app)
      .post('/api/reservas')
      .send({
        clienteId: 9999,
        proveedorId: 1,
        fechaHoraInicio: '2026-11-10T11:00:00-05:00',
        duracionMinutos: 30
      })
      .expect(404);

    assert.equal(res.body.error, 'Recurso no encontrado');
    assert.match(res.body.detalle, /cliente/i);
  });

  // 8. Reserva con un proveedor inexistente
  test('8. Reserva con un proveedor inexistente', async () => {
    const res = await request(app)
      .post('/api/reservas')
      .send({
        clienteId: 1,
        proveedorId: 9999,
        fechaHoraInicio: '2026-11-10T11:00:00-05:00',
        duracionMinutos: 30
      })
      .expect(404);

    assert.equal(res.body.error, 'Recurso no encontrado');
    assert.match(res.body.detalle, /proveedor/i);
  });

  // 9. Fecha u hora inválida
  test('9. Fecha u hora inválida (no ISO 8601 o fecha inexistente)', async () => {
    // Formato no ISO
    const res1 = await request(app)
      .post('/api/reservas')
      .send({
        clienteId: 1,
        proveedorId: 1,
        fechaHoraInicio: '10-11-2026 10:00 AM',
        duracionMinutos: 30
      })
      .expect(400);

    assert.equal(res1.body.error, 'Solicitud inválida');

    // Fecha en el pasado
    const resPast = await request(app)
      .post('/api/reservas')
      .send({
        clienteId: 1,
        proveedorId: 1,
        fechaHoraInicio: '2020-01-01T10:00:00Z',
        duracionMinutos: 30
      })
      .expect(400);

    assert.match(resPast.body.detalle, /pasadas/i);
  });

  // 10. Duración inválida
  test('10. Duración inválida (negativa, cero, no numérica o fuera de límites)', async () => {
    const resCero = await request(app)
      .post('/api/reservas')
      .send({
        clienteId: 1,
        proveedorId: 1,
        fechaHoraInicio: '2026-11-10T10:00:00-05:00',
        duracionMinutos: 0
      })
      .expect(400);

    assert.equal(resCero.body.error, 'Solicitud inválida');

    const resNegativa = await request(app)
      .post('/api/reservas')
      .send({
        clienteId: 1,
        proveedorId: 1,
        fechaHoraInicio: '2026-11-10T10:00:00-05:00',
        duracionMinutos: -15
      })
      .expect(400);

    assert.equal(resNegativa.body.error, 'Solicitud inválida');
  });

  // 11. Reserva fuera del horario de atención o día no laborable
  test('11. Reserva fuera del horario de atención o en día no laborable', async () => {
    // Proveedor 1 atiende de 08:00 a 17:00 de Lunes a Viernes.
    // 1. Horario fuera de atención (06:00 AM)
    const resFueraHora = await request(app)
      .post('/api/reservas')
      .send({
        clienteId: 1,
        proveedorId: 1,
        fechaHoraInicio: '2026-11-10T06:00:00-05:00',
        duracionMinutos: 30
      })
      .expect(400);

    assert.match(resFueraHora.body.detalle, /horario de atención/i);

    // 2. Día no laborable: 2026-11-15 es Domingo (proveedor 1 solo atiende 1..5)
    const resDiaNoLaborable = await request(app)
      .post('/api/reservas')
      .send({
        clienteId: 1,
        proveedorId: 1,
        fechaHoraInicio: '2026-11-15T10:00:00-05:00',
        duracionMinutos: 30
      })
      .expect(400);

    assert.match(resDiaNoLaborable.body.detalle, /no atiende en el día/i);
  });

  // 12. Cancelación de una reserva
  test('12. Cancelación de una reserva confirmada', async () => {
    const resCrear = await request(app)
      .post('/api/reservas')
      .send({
        clienteId: 1,
        proveedorId: 1,
        fechaHoraInicio: '2026-11-10T14:00:00-05:00',
        duracionMinutos: 30
      })
      .expect(201);

    const reservaId = resCrear.body.id;

    const resCancelar = await request(app)
      .patch(`/api/reservas/${reservaId}/cancelar`)
      .expect(200);

    assert.equal(resCancelar.body.id, reservaId);
    assert.equal(resCancelar.body.estado, 'cancelada');
  });

  // 13. Creación de una nueva reserva en el horario liberado
  test('13. Creación de una nueva reserva en el horario previamente liberado', async () => {
    // 1. Crear reserva
    const res1 = await request(app)
      .post('/api/reservas')
      .send({
        clienteId: 1,
        proveedorId: 1,
        fechaHoraInicio: '2026-11-10T15:00:00-05:00',
        duracionMinutos: 30
      })
      .expect(201);

    // 2. Cancelar la reserva
    await request(app)
      .patch(`/api/reservas/${res1.body.id}/cancelar`)
      .expect(200);

    // 3. Crear una nueva reserva exactamente en el mismo horario liberado
    const resNueva = await request(app)
      .post('/api/reservas')
      .send({
        clienteId: 2,
        proveedorId: 1,
        fechaHoraInicio: '2026-11-10T15:00:00-05:00',
        duracionMinutos: 30
      })
      .expect(201);

    assert.ok(resNueva.body.id);
    assert.equal(resNueva.body.estado, 'confirmada');
    assert.notEqual(resNueva.body.id, res1.body.id);
  });

  // 14. Reintento de cancelación
  test('14. Reintento de cancelación de una reserva ya cancelada', async () => {
    // 1. Crear reserva
    const res1 = await request(app)
      .post('/api/reservas')
      .send({
        clienteId: 1,
        proveedorId: 1,
        fechaHoraInicio: '2026-11-10T16:00:00-05:00',
        duracionMinutos: 30
      })
      .expect(201);

    // 2. Primera cancelación (éxito 200)
    await request(app)
      .patch(`/api/reservas/${res1.body.id}/cancelar`)
      .expect(200);

    // 3. Segundo intento de cancelación (409 Conflicto)
    const resReintento = await request(app)
      .patch(`/api/reservas/${res1.body.id}/cancelar`)
      .expect(409);

    assert.equal(resReintento.body.error, 'Conflicto de estado');
    assert.match(resReintento.body.detalle, /ya se encuentra cancelada/i);
  });

  // 15. Filtros de búsqueda
  test('15. Filtros de búsqueda en GET /api/reservas', async () => {
    // Crear dos reservas
    await request(app)
      .post('/api/reservas')
      .send({
        clienteId: 1,
        proveedorId: 1,
        fechaHoraInicio: '2026-11-10T09:00:00-05:00',
        duracionMinutos: 30
      })
      .expect(201);

    const r2 = await request(app)
      .post('/api/reservas')
      .send({
        clienteId: 2,
        proveedorId: 2,
        fechaHoraInicio: '2026-11-10T11:00:00-05:00',
        duracionMinutos: 45
      })
      .expect(201);

    await request(app).patch(`/api/reservas/${r2.body.id}/cancelar`).expect(200);

    // Filtrar por estado confirmada
    const resConfirmadas = await request(app)
      .get('/api/reservas?estado=confirmada')
      .expect(200);
    assert.ok(resConfirmadas.body.every((r) => r.estado === 'confirmada'));

    // Filtrar por clienteId
    const resCliente1 = await request(app)
      .get('/api/reservas?clienteId=1')
      .expect(200);
    assert.ok(resCliente1.body.every((r) => r.clienteId === 1));

    // Filtro no permitido / inválido rechazado con 400
    const resInvalido = await request(app)
      .get('/api/reservas?parametroDesconocido=123')
      .expect(400);
    assert.equal(resInvalido.body.error, 'Solicitud inválida');
  });

  // 16. Dos solicitudes concurrentes para el mismo intervalo
  test('16. Dos solicitudes concurrentes para el mismo intervalo: exactamente una confirmada', async () => {
    const reservaData = {
      clienteId: 1,
      proveedorId: 1,
      fechaHoraInicio: '2026-11-10T12:00:00-05:00',
      duracionMinutos: 30
    };

    // Disparar ambas solicitudes al mismo tiempo
    const [resA, resB] = await Promise.all([
      request(app).post('/api/reservas').send(reservaData),
      request(app).post('/api/reservas').send({ ...reservaData, clienteId: 2 })
    ]);

    const statuses = [resA.status, resB.status].sort();
    assert.deepEqual(statuses, [201, 409], 'Una solicitud debe devolver 201 y la otra 409');

    // La rechazada debe cumplir exactamente el formato obligatorio de conflicto de horario
    const rejectedRes = resA.status === 409 ? resA : resB;
    assert.deepEqual(rejectedRes.body, {
      error: 'Conflicto de horario',
      detalle: 'El proveedor ya tiene una reserva en el intervalo solicitado.'
    });
  });

  // 17. Actualización de cliente vía PUT /api/clientes/:id
  test('17. Actualización de cliente vía PUT /api/clientes/:id', async () => {
    // Crear cliente
    const nuevo = await request(app)
      .post('/api/clientes')
      .send({
        nombre: 'Camilo Sampedro',
        email: 'camilo.s@email.com',
        telefono: '+573105554433'
      })
      .expect(201);

    // Actualizar cliente
    const datosActualizados = {
      nombre: 'Camilo Sampedro Editado',
      email: 'camilo.editado@email.com',
      telefono: '+573109998877'
    };

    const resPut = await request(app)
      .put(`/api/clientes/${nuevo.body.id}`)
      .send(datosActualizados)
      .expect(200);

    assert.equal(resPut.body.id, nuevo.body.id);
    assert.equal(resPut.body.nombre, datosActualizados.nombre);
    assert.equal(resPut.body.email, datosActualizados.email);
    assert.equal(resPut.body.telefono, datosActualizados.telefono);

    // Error 404 al actualizar inexistente
    await request(app)
      .put('/api/clientes/99999')
      .send(datosActualizados)
      .expect(404);
  });

  // 18. Eliminación física vía DELETE /api/clientes/:id y DELETE /api/reservas/:id
  test('18. Eliminación física vía DELETE /api/clientes/:id y DELETE /api/reservas/:id', async () => {
    // Crear cliente sin reservas
    const cliente = await request(app)
      .post('/api/clientes')
      .send({
        nombre: 'Cliente Para Borrar',
        email: 'borrar@email.com'
      })
      .expect(201);

    // Eliminar cliente
    const resDelCliente = await request(app)
      .delete(`/api/clientes/${cliente.body.id}`)
      .expect(200);

    assert.equal(resDelCliente.body.id, cliente.body.id);

    // Verificar que ya no existe (404)
    await request(app).get(`/api/clientes/${cliente.body.id}`).expect(404);

    // Crear y luego eliminar una reserva
    const resReserva = await request(app)
      .post('/api/reservas')
      .send({
        clienteId: 1,
        proveedorId: 1,
        fechaHoraInicio: '2026-11-10T08:30:00-05:00',
        duracionMinutos: 30
      })
      .expect(201);

    const resDelReserva = await request(app)
      .delete(`/api/reservas/${resReserva.body.id}`)
      .expect(200);

    assert.equal(resDelReserva.body.id, resReserva.body.id);

    // Verificar que ya no existe (404)
    await request(app).get(`/api/reservas/${resReserva.body.id}`).expect(404);
  });
});

