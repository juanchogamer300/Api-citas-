const ClienteRepository = require('../repositories/clienteRepository');
const { NotFoundError, ConflictError } = require('../utils/errors');

class ClienteService {
  constructor(clienteRepository) {
    this.clienteRepository = clienteRepository || new ClienteRepository();
  }

  obtenerTodos() {
    return this.clienteRepository.findAll();
  }

  obtenerPorId(id) {
    const cliente = this.clienteRepository.findById(id);
    if (!cliente) {
      throw new NotFoundError(`No existe un cliente con el id ${id}.`);
    }
    return cliente;
  }

  crearCliente(datos) {
    const existente = this.clienteRepository.findByEmail(datos.email);
    if (existente) {
      throw new ConflictError(
        'Ya existe un cliente registrado con ese correo electrónico.',
        'Conflicto de datos'
      );
    }
    return this.clienteRepository.create(datos);
  }

  actualizarCliente(id, datos) {
    this.obtenerPorId(id);

    const emailEnUso = this.clienteRepository.findByEmail(datos.email);
    if (emailEnUso && emailEnUso.id !== id) {
      throw new ConflictError(
        'Ya existe otro cliente registrado con ese correo electrónico.',
        'Conflicto de datos'
      );
    }

    return this.clienteRepository.update(id, datos);
  }

  eliminarCliente(id) {
    this.obtenerPorId(id);

    try {
      this.clienteRepository.delete(id);
      return {
        mensaje: 'Cliente eliminado exitosamente.',
        id
      };
    } catch (err) {
      if (err.code === 'SQLITE_CONSTRAINT_FOREIGNKEY' || err.code === 'SQLITE_CONSTRAINT_TRIGGER') {
        throw new ConflictError(
          'No es posible eliminar el cliente porque tiene reservas registradas en el sistema.',
          'Conflicto de integridad referencial'
        );
      }
      throw err;
    }
  }
}

module.exports = ClienteService;
