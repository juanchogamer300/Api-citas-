const ClienteRepository = require('../repositories/clienteRepository');
const ProveedorRepository = require('../repositories/proveedorRepository');
const ReservaRepository = require('../repositories/reservaRepository');
const config = require('../config/env');
const {
  NotFoundError,
  BadRequestError,
  ConflictError
} = require('../utils/errors');
const {
  toUtcIso,
  isPast,
  validateWithinSchedule
} = require('../utils/dateUtils');

class ReservaService {
  constructor(reservaRepository, clienteRepository, proveedorRepository) {
    this.reservaRepository = reservaRepository || new ReservaRepository();
    this.clienteRepository = clienteRepository || new ClienteRepository();
    this.proveedorRepository = proveedorRepository || new ProveedorRepository();
  }

  crearReserva({ clienteId, proveedorId, fechaHoraInicioDt, duracionMinutos }) {
    // 1. Validar que la fecha y hora no sea pasada
    if (isPast(fechaHoraInicioDt)) {
      throw new BadRequestError('No es posible realizar reservas en fechas u horas pasadas.');
    }

    // 2. Calcular fechaHoraFin sumando duracionMinutos a fechaHoraInicio
    const fechaHoraFinDt = fechaHoraInicioDt.plus({ minutes: duracionMinutos });

    // 3. Validar existencia del cliente
    const cliente = this.clienteRepository.findById(clienteId);
    if (!cliente) {
      throw new NotFoundError(`El cliente con id ${clienteId} no existe.`);
    }

    // 4. Validar existencia y estado activo del proveedor
    const proveedor = this.proveedorRepository.findById(proveedorId);
    if (!proveedor) {
      throw new NotFoundError(`El proveedor con id ${proveedorId} no existe.`);
    }

    if (proveedor.activo !== 1) {
      throw new BadRequestError('El proveedor seleccionado no se encuentra activo para recibir reservas.');
    }

    // 5. Validar que la reserva coincida con los días y horarios de atención del proveedor
    validateWithinSchedule(
      fechaHoraInicioDt,
      fechaHoraFinDt,
      proveedor.horaApertura,
      proveedor.horaCierre,
      proveedor.diasAtencion,
      config.timezone
    );

    // 6. Normalizar instantes a cadenas ISO 8601 UTC
    const fechaHoraInicioUtc = toUtcIso(fechaHoraInicioDt);
    const fechaHoraFinUtc = toUtcIso(fechaHoraFinDt);

    // 7. Ejecutar inserción y prevención de solapamientos en una transacción atómica serializada
    return this.reservaRepository.createAtomic({
      clienteId,
      proveedorId,
      fechaHoraInicio: fechaHoraInicioUtc,
      fechaHoraFin: fechaHoraFinUtc
    });
  }

  obtenerTodas(filtros = {}) {
    return this.reservaRepository.findAll(filtros);
  }

  obtenerPorId(id) {
    const reserva = this.reservaRepository.findById(id);
    if (!reserva) {
      throw new NotFoundError(`La reserva con id ${id} no existe.`);
    }
    return reserva;
  }

  cancelarReserva(id) {
    const resultado = this.reservaRepository.cancelarAtomic(id);

    if (resultado.notFound) {
      throw new NotFoundError(`La reserva con id ${id} no existe.`);
    }

    if (resultado.alreadyCancelled) {
      throw new ConflictError(
        'La reserva ya se encuentra cancelada.',
        'Conflicto de estado'
      );
    }

    return resultado.reserva;
  }

  eliminarReserva(id) {
    this.obtenerPorId(id);
    this.reservaRepository.delete(id);
    return {
      mensaje: 'Reserva eliminada exitosamente.',
      id
    };
  }
}

module.exports = ReservaService;

