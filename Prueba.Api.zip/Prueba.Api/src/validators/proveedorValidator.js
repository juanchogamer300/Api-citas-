const { BadRequestError } = require('../utils/errors');
const { parseDateParam } = require('../utils/dateUtils');
const { validateIdParam } = require('./clienteValidator');

function validateProveedorId(idParam) {
  return validateIdParam(idParam, 'proveedor');
}

function validateDisponibilidadQuery(query) {
  if (!query || !query.fecha) {
    throw new BadRequestError("El parámetro de consulta 'fecha' es obligatorio (formato YYYY-MM-DD).");
  }

  // Valida que sea fecha real YYYY-MM-DD
  const dateObj = parseDateParam(query.fecha);

  return {
    fecha: query.fecha.trim(),
    dateTime: dateObj
  };
}

module.exports = {
  validateProveedorId,
  validateDisponibilidadQuery
};
