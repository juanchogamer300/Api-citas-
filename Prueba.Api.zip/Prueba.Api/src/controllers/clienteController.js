const ClienteService = require('../services/clienteService');
const { validateCreateCliente, validateIdParam } = require('../validators/clienteValidator');

class ClienteController {
  constructor(clienteService) {
    this.clienteService = clienteService || new ClienteService();
  }

  crearCliente = async (req, res, next) => {
    try {
      const datosValidados = validateCreateCliente(req.body);
      const nuevoCliente = this.clienteService.crearCliente(datosValidados);
      return res.status(201).json(nuevoCliente);
    } catch (error) {
      next(error);
    }
  };

  listarClientes = async (req, res, next) => {
    try {
      const clientes = this.clienteService.obtenerTodos();
      return res.status(200).json(clientes);
    } catch (error) {
      next(error);
    }
  };

  obtenerClientePorId = async (req, res, next) => {
    try {
      const id = validateIdParam(req.params.id, 'cliente');
      const cliente = this.clienteService.obtenerPorId(id);
      return res.status(200).json(cliente);
    } catch (error) {
      next(error);
    }
  };

  actualizarCliente = async (req, res, next) => {
    try {
      const id = validateIdParam(req.params.id, 'cliente');
      const datosValidados = validateCreateCliente(req.body);
      const clienteActualizado = this.clienteService.actualizarCliente(id, datosValidados);
      return res.status(200).json(clienteActualizado);
    } catch (error) {
      next(error);
    }
  };

  eliminarCliente = async (req, res, next) => {
    try {
      const id = validateIdParam(req.params.id, 'cliente');
      const resultado = this.clienteService.eliminarCliente(id);
      return res.status(200).json(resultado);
    } catch (error) {
      next(error);
    }
  };
}

module.exports = ClienteController;

