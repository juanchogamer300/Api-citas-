const express = require('express');
const cors = require('cors');
const createApiRouter = require('./routes');
const errorHandler = require('./middlewares/errorHandler');
const notFoundHandler = require('./middlewares/notFoundHandler');
const ClienteRepository = require('./repositories/clienteRepository');
const ProveedorRepository = require('./repositories/proveedorRepository');
const ReservaRepository = require('./repositories/reservaRepository');
const ClienteService = require('./services/clienteService');
const ProveedorService = require('./services/proveedorService');
const ReservaService = require('./services/reservaService');
const { getDatabase } = require('./database/connection');
const { initSchema } = require('./database/schema');
const { seedDatabase } = require('./database/seed');

const path = require('node:path');

// Factoría para instanciar la aplicación Express con inyección de dependencias.
function createApp(options = {}) {
  const db = options.db || getDatabase();

  // Asegurar esquema base
  initSchema(db);

  if (options.seed !== false) {
    seedDatabase(db);
  }

  // Repositorios
  const clienteRepository = new ClienteRepository(db);
  const proveedorRepository = new ProveedorRepository(db);
  const reservaRepository = new ReservaRepository(db);

  // Servicios
  const clienteService = new ClienteService(clienteRepository);
  const proveedorService = new ProveedorService(proveedorRepository, reservaRepository);
  const reservaService = new ReservaService(
    reservaRepository,
    clienteRepository,
    proveedorRepository
  );

  const app = express();

  // Middlewares globales
  app.use(cors());
  app.use(express.json());

  // Servir archivos estáticos del frontend desde la carpeta public
  app.use(express.static(path.join(__dirname, '../public')));

  // Endpoint de comprobación de salud del servicio
  app.get('/health', (req, res) => {
    res.status(200).json({
      status: 'ok',
      service: 'sistema-reservas-citas-api',
      uptime: process.uptime(),
      timestamp: new Date().toISOString()
    });
  });

  // Enrutador de la API
  app.use(
    '/api',
    createApiRouter({
      clienteService,
      proveedorService,
      reservaService
    })
  );

  // Manejador de rutas no encontradas (404)
  app.use(notFoundHandler);

  // Manejador centralizado de errores
  app.use(errorHandler);

  return app;
}

module.exports = {
  createApp
};
