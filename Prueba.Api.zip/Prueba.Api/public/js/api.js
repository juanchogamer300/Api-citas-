/**
 * Cliente de consumo de API REST para el Sistema de Reservas
 */
const API = {
  baseUrl: window.location.origin,

  async request(endpoint, options = {}) {
    const url = `${this.baseUrl}${endpoint}`;
    const defaultHeaders = {
      'Content-Type': 'application/json'
    };

    const config = {
      ...options,
      headers: {
        ...defaultHeaders,
        ...options.headers
      }
    };

    if (config.body && typeof config.body === 'object') {
      config.body = JSON.stringify(config.body);
    }

    try {
      const response = await fetch(url, config);
      const isJson = response.headers.get('content-type')?.includes('application/json');
      const data = isJson ? await response.json() : null;

      if (!response.ok) {
        const error = new Error(data?.detalle || data?.error || `Error HTTP ${response.status}`);
        error.status = response.status;
        error.data = data;
        throw error;
      }

      return data;
    } catch (err) {
      console.error(`[API Error] ${options.method || 'GET'} ${endpoint}:`, err);
      throw err;
    }
  },

  // Health
  checkHealth() {
    return this.request('/health');
  },

  // Proveedores
  proveedores: {
    list() {
      return API.request('/api/proveedores');
    },
    get(id) {
      return API.request(`/api/proveedores/${id}`);
    },
    disponibilidad(id, fecha) {
      return API.request(`/api/proveedores/${id}/disponibilidad?fecha=${fecha}`);
    }
  },

  // Clientes
  clientes: {
    list() {
      return API.request('/api/clientes');
    },
    get(id) {
      return API.request(`/api/clientes/${id}`);
    },
    create(data) {
      return API.request('/api/clientes', {
        method: 'POST',
        body: data
      });
    },
    update(id, data) {
      return API.request(`/api/clientes/${id}`, {
        method: 'PUT',
        body: data
      });
    },
    delete(id) {
      return API.request(`/api/clientes/${id}`, {
        method: 'DELETE'
      });
    }
  },

  // Reservas
  reservas: {
    list(filters = {}) {
      const params = new URLSearchParams();
      if (filters.clienteId) params.append('clienteId', filters.clienteId);
      if (filters.proveedorId) params.append('proveedorId', filters.proveedorId);
      if (filters.estado) params.append('estado', filters.estado);
      if (filters.fechaDesde) params.append('fechaDesde', filters.fechaDesde);
      if (filters.fechaHasta) params.append('fechaHasta', filters.fechaHasta);
      
      const queryStr = params.toString() ? `?${params.toString()}` : '';
      return API.request(`/api/reservas${queryStr}`);
    },
    get(id) {
      return API.request(`/api/reservas/${id}`);
    },
    create(data) {
      return API.request('/api/reservas', {
        method: 'POST',
        body: data
      });
    },
    cancel(id) {
      return API.request(`/api/reservas/${id}/cancelar`, {
        method: 'PATCH'
      });
    },
    delete(id) {
      return API.request(`/api/reservas/${id}`, {
        method: 'DELETE'
      });
    }
  }
};

window.API = API;
