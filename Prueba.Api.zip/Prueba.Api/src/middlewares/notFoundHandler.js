function notFoundHandler(req, res) {
  return res.status(404).json({
    error: 'Recurso no encontrado',
    detalle: `La ruta solicitada '${req.method} ${req.originalUrl}' no existe en este servidor.`
  });
}

module.exports = notFoundHandler;
