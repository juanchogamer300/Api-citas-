/**
 * Inicializa las tablas e índices del sistema en la base de datos suministrada.
 * @param {import('better-sqlite3').Database} db
 */
function initSchema(db) {
  const schemaSql = `
    CREATE TABLE IF NOT EXISTS clientes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nombre TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE COLLATE NOCASE,
      telefono TEXT,
      createdAt TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );

    CREATE TABLE IF NOT EXISTS proveedores (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nombre TEXT NOT NULL,
      tipo TEXT NOT NULL,
      duracionMinutos INTEGER NOT NULL CHECK (duracionMinutos > 0),
      horaApertura TEXT NOT NULL,
      horaCierre TEXT NOT NULL,
      diasAtencion TEXT NOT NULL,
      activo INTEGER NOT NULL DEFAULT 1 CHECK (activo IN (0, 1)),
      createdAt TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );

    CREATE TABLE IF NOT EXISTS reservas (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      clienteId INTEGER NOT NULL,
      proveedorId INTEGER NOT NULL,
      fechaHoraInicio TEXT NOT NULL,
      fechaHoraFin TEXT NOT NULL,
      estado TEXT NOT NULL CHECK (estado IN ('confirmada', 'cancelada')) DEFAULT 'confirmada',
      createdAt TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
      FOREIGN KEY (clienteId) REFERENCES clientes(id) ON UPDATE CASCADE ON DELETE RESTRICT,
      FOREIGN KEY (proveedorId) REFERENCES proveedores(id) ON UPDATE CASCADE ON DELETE RESTRICT
    );

    CREATE INDEX IF NOT EXISTS idx_clientes_email ON clientes(email);
    CREATE INDEX IF NOT EXISTS idx_proveedores_activo ON proveedores(activo);
    CREATE INDEX IF NOT EXISTS idx_reservas_solapamiento ON reservas(proveedorId, estado, fechaHoraInicio, fechaHoraFin);
    CREATE INDEX IF NOT EXISTS idx_reservas_clienteId ON reservas(clienteId);
  `;

  db.exec(schemaSql);
}

module.exports = {
  initSchema
};
