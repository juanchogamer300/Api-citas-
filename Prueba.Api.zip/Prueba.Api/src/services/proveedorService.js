const { DateTime } = require('luxon');
const ProveedorRepository = require('../repositories/proveedorRepository');
const ReservaRepository = require('../repositories/reservaRepository');
const config = require('../config/env');
const { NotFoundError, BadRequestError } = require('../utils/errors');
const {
  normalizeDaysOfWeek,
  generateSlotsForDay
} = require('../utils/dateUtils');

class ProveedorService {
  constructor(proveedorRepository, reservaRepository) {
    this.proveedorRepository = proveedorRepository || new ProveedorRepository();
    this.reservaRepository = reservaRepository || new ReservaRepository();
  }

  obtenerActivos() {
    return this.proveedorRepository.findAllActive();
  }

  obtenerPorId(id) {
    const proveedor = this.proveedorRepository.findById(id);
    if (!proveedor) {
      throw new NotFoundError(`No existe un proveedor con el id ${id}.`);
    }
    return proveedor;
  }

  obtenerDisponibilidad(id, dateStr) {
    const proveedor = this.obtenerPorId(id);

    if (proveedor.activo !== 1) {
      throw new BadRequestError('El proveedor seleccionado no se encuentra activo para recibir reservas.');
    }

    const timezone = config.timezone;
    const diasPermitidos = normalizeDaysOfWeek(proveedor.diasAtencion);

    // Determinar día de la semana para la fecha solicitada en la zona horaria del negocio
    const fechaObj = DateTime.fromISO(dateStr, { zone: timezone });
    const diaSemana = fechaObj.weekday; // 1 = Lunes, 7 = Domingo

    // Estructura base de respuesta documentada
    const respuesta = {
      fecha: dateStr,
      zonaHoraria: timezone,
      proveedor: {
        id: proveedor.id,
        nombre: proveedor.nombre,
        tipo: proveedor.tipo,
        duracionMinutos: proveedor.duracionMinutos,
        horaApertura: proveedor.horaApertura,
        horaCierre: proveedor.horaCierre,
        diasAtencion: diasPermitidos
      },
      intervalosDisponibles: []
    };

    // Si el proveedor no atiende este día de la semana, retorna lista vacía
    if (!diasPermitidos.includes(diaSemana)) {
      return respuesta;
    }

    // Generar intervalos candidatos basados en la duración predeterminada
    const slots = generateSlotsForDay(
      dateStr,
      proveedor.horaApertura,
      proveedor.horaCierre,
      proveedor.duracionMinutos,
      timezone
    );

    if (slots.length === 0) {
      return respuesta;
    }

    // Rango del día completo en UTC para consultar reservas confirmadas existentes
    const inicioDiaUtc = slots[0].inicio.toUTC().toISO();
    const finDiaUtc = slots[slots.length - 1].fin.toUTC().toISO();

    const reservasConfirmadas = this.reservaRepository.findConfirmedOverlaps(
      proveedor.id,
      inicioDiaUtc,
      finDiaUtc
    );

    const nowMillis = DateTime.now().toMillis();

    // Filtrar intervalos: excluir pasados y excluir solapados con reservas confirmadas
    for (const slot of slots) {
      // 1. Excluir intervalos que ya hayan comenzado en el pasado
      if (slot.inicio.toMillis() <= nowMillis) {
        continue;
      }

      const slotInicioUtc = slot.inicio.toUTC().toISO();
      const slotFinUtc = slot.fin.toUTC().toISO();

      // 2. Comprobar solapamiento: slotInicio < resFin && slotFin > resInicio
      const solapada = reservasConfirmadas.some(
        (res) => slotInicioUtc < res.fechaHoraFin && slotFinUtc > res.fechaHoraInicio
      );

      if (!solapada) {
        respuesta.intervalosDisponibles.push({
          inicio: slot.inicio.toISO(),
          fin: slot.fin.toISO(),
          inicioUtc: slotInicioUtc,
          finUtc: slotFinUtc
        });
      }
    }

    return respuesta;
  }
}

module.exports = ProveedorService;
