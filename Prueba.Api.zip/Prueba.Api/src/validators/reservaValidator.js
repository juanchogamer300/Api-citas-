const { BadRequestError } = require('../utils/errors');
const { parseAndValidateIso } = require('../utils/dateUtils');
const { validateIdParam } = require('./clienteValidator');

const MIN_DURACION_MINUTOS = 5;
const MAX_DURACION_MINUTOS = 480; // 8 horas máximo por cita

function validateCreateReserva(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    throw new BadRequestError('El cuerpo de la solicitud debe ser un objeto JSON válido.');
  }

  const { clienteId, proveedorId, fechaHoraInicio, duracionMinutos } = body;

  // 1. clienteId
  if (clienteId === undefined || clienteId === null) {
    throw new BadRequestError("El campo 'clienteId' es obligatorio.");
  }
  const parsedClienteId = Number(clienteId);
  if (!Number.isInteger(parsedClienteId) || parsedClienteId <= 0) {
    throw new BadRequestError("El campo 'clienteId' debe ser un número entero positivo.");
  }

  // 2. proveedorId
  if (proveedorId === undefined || proveedorId === null) {
    throw new BadRequestError("El campo 'proveedorId' es obligatorio.");
  }
  const parsedProveedorId = Number(proveedorId);
  if (!Number.isInteger(parsedProveedorId) || parsedProveedorId <= 0) {
    throw new BadRequestError("El campo 'proveedorId' debe ser un número entero positivo.");
  }

  // 3. fechaHoraInicio
  if (!fechaHoraInicio) {
    throw new BadRequestError("El campo 'fechaHoraInicio' es obligatorio.");
  }
  const inicioDateTime = parseAndValidateIso(fechaHoraInicio, 'fechaHoraInicio');

  // 4. duracionMinutos
  if (duracionMinutos === undefined || duracionMinutos === null) {
    throw new BadRequestError("El campo 'duracionMinutos' es obligatorio.");
  }
  const parsedDuracion = Number(duracionMinutos);
  if (!Number.isInteger(parsedDuracion) || parsedDuracion <= 0) {
    throw new BadRequestError("El campo 'duracionMinutos' debe ser un número entero positivo.");
  }
  if (parsedDuracion < MIN_DURACION_MINUTOS || parsedDuracion > MAX_DURACION_MINUTOS) {
    throw new BadRequestError(
      `El campo 'duracionMinutos' debe estar comprendido entre ${MIN_DURACION_MINUTOS} y ${MAX_DURACION_MINUTOS} minutos.`
    );
  }

  return {
    clienteId: parsedClienteId,
    proveedorId: parsedProveedorId,
    fechaHoraInicioDt: inicioDateTime,
    duracionMinutos: parsedDuracion
  };
}

function validateReservaFilters(query = {}) {
  const allowedParams = new Set(['clienteId', 'proveedorId', 'estado', 'fechaDesde', 'fechaHasta']);

  // Validar que no se envíen filtros desconocidos
  for (const key of Object.keys(query)) {
    if (!allowedParams.has(key)) {
      throw new BadRequestError(`Parámetro de filtro no permitido o inválido: '${key}'.`);
    }
  }

  const filters = {};

  if (query.clienteId !== undefined) {
    const cid = Number(query.clienteId);
    if (!Number.isInteger(cid) || cid <= 0) {
      throw new BadRequestError("El filtro 'clienteId' debe ser un número entero positivo.");
    }
    filters.clienteId = cid;
  }

  if (query.proveedorId !== undefined) {
    const pid = Number(query.proveedorId);
    if (!Number.isInteger(pid) || pid <= 0) {
      throw new BadRequestError("El filtro 'proveedorId' debe ser un número entero positivo.");
    }
    filters.proveedorId = pid;
  }

  if (query.estado !== undefined) {
    const estado = String(query.estado).toLowerCase().trim();
    if (estado !== 'confirmada' && estado !== 'cancelada') {
      throw new BadRequestError("El filtro 'estado' solo admite los valores 'confirmada' o 'cancelada'.");
    }
    filters.estado = estado;
  }

  if (query.fechaDesde !== undefined) {
    const dtDesde = parseAndValidateIso(query.fechaDesde, 'fechaDesde');
    filters.fechaDesde = dtDesde.toUTC().toISO();
  }

  if (query.fechaHasta !== undefined) {
    const dtHasta = parseAndValidateIso(query.fechaHasta, 'fechaHasta');
    filters.fechaHasta = dtHasta.toUTC().toISO();
  }

  if (filters.fechaDesde && filters.fechaHasta && filters.fechaDesde > filters.fechaHasta) {
    throw new BadRequestError("El filtro 'fechaDesde' no puede ser posterior a 'fechaHasta'.");
  }

  return filters;
}

module.exports = {
  validateCreateReserva,
  validateReservaFilters,
  validateReservaId: (id) => validateIdParam(id, 'reserva')
};
