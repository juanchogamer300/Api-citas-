const { Router } = require('express');
const ClienteController = require('../controllers/clienteController');

function createClienteRoutes(clienteService) {
  const router = Router();
  const controller = new ClienteController(clienteService);

  router.post('/', controller.crearCliente);
  router.get('/', controller.listarClientes);
  router.get('/:id', controller.obtenerClientePorId);
  router.put('/:id', controller.actualizarCliente);
  router.delete('/:id', controller.eliminarCliente);

  return router;
}

module.exports = createClienteRoutes;
