const path = require('node:path');
const dotenv = require('dotenv');

// Cargar variables de entorno desde .env si existe
dotenv.config();

const config = {
  port: parseInt(process.env.PORT || '3000', 10),
  nodeEnv: process.env.NODE_ENV || 'development',
  dbPath: process.env.DB_PATH || path.resolve(process.cwd(), 'data', 'reservas.db'),
  timezone: process.env.TIMEZONE || 'America/Bogota'
};

module.exports = config;
