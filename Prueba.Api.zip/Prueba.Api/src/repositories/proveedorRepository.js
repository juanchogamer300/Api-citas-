const { getDatabase } = require('../database/connection');

class ProveedorRepository {
  constructor(db) {
    this.db = db || getDatabase();
  }

  findById(id) {
    const stmt = this.db.prepare('SELECT * FROM proveedores WHERE id = ?');
    return stmt.get(id);
  }

  findAllActive() {
    const stmt = this.db.prepare('SELECT * FROM proveedores WHERE activo = 1 ORDER BY id ASC');
    return stmt.all();
  }

  create({ nombre, tipo, duracionMinutos, horaApertura, horaCierre, diasAtencion, activo = 1 }) {
    const stmt = this.db.prepare(`
      INSERT INTO proveedores (nombre, tipo, duracionMinutos, horaApertura, horaCierre, diasAtencion, activo)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    const info = stmt.run(
      nombre.trim(),
      tipo.trim(),
      duracionMinutos,
      horaApertura.trim(),
      horaCierre.trim(),
      typeof diasAtencion === 'string' ? diasAtencion : JSON.stringify(diasAtencion),
      activo ? 1 : 0
    );
    return this.findById(info.lastInsertRowid);
  }
}

module.exports = ProveedorRepository;
