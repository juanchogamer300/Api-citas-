const { Router } = require('express');
const ReservaController = require('../controllers/reservaController');

function createReservaRoutes(reservaService) {
  const router = Router();
  const controller = new ReservaController(reservaService);

  router.post('/', controller.crearReserva);
  router.get('/', controller.listarReservas);
  router.get('/:id', controller.obtenerReservaPorId);
  router.patch('/:id/cancelar', controller.cancelarReserva);
  router.delete('/:id', controller.eliminarReserva);

  return router;
}

module.exports = createReservaRoutes;
