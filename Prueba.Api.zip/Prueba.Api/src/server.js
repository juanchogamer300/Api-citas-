const { createApp } = require('./app');
const config = require('./config/env');
const { closeDatabase } = require('./database/connection');

const app = createApp();

const server = app.listen(config.port, () => {
  console.log(`=======================================================`);
  console.log(`  Sistema de Reservas de Citas y Turnos - API REST`);
  console.log(`  Servidor activo en: http://localhost:${config.port}`);
  console.log(`  Entorno: ${config.nodeEnv}`);
  console.log(`  Zona Horaria: ${config.timezone}`);
  console.log(`  Base de datos: ${config.dbPath}`);
  console.log(`=======================================================`);
});

function gracefulShutdown(signal) {
  console.log(`\nSeñal ${signal} recibida. Cerrando servidor y base de datos...`);
  server.close(() => {
    closeDatabase();
    console.log('Servidor y base de datos cerrados correctamente. Proceso terminado.');
    process.exit(0);
  });
}

process.on('SIGINT', () => gracefulShutdown('SIGINT'));
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));

module.exports = server;
