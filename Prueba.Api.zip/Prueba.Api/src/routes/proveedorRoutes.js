const { Router } = require('express');
const ProveedorController = require('../controllers/proveedorController');

function createProveedorRoutes(proveedorService) {
  const router = Router();
  const controller = new ProveedorController(proveedorService);

  router.get('/', controller.listarProveedores);
  router.get('/:id', controller.obtenerProveedorPorId);
  router.get('/:id/disponibilidad', controller.obtenerDisponibilidad);

  return router;
}

module.exports = createProveedorRoutes;
