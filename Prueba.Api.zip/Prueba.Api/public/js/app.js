/**
 * Lógica principal del Frontend de ReservaPro / CitaFlow
 */

// Estado global de la aplicación
const AppState = {
  currentTab: 'agenda',
  proveedores: [],
  clientes: [],
  reservas: [],
  selectedProveedorId: null,
  selectedFecha: null,
  selectedSlot: null,
  selectedClienteId: null
};

document.addEventListener('DOMContentLoaded', async () => {
  Modal.init();
  setupTabNavigation();
  setupDateHelpers();
  setupEventListeners();

  // Cargar datos iniciales
  await checkHealthStatus();
  await loadInitialData();
});

// Comprobar estado del servidor
async function checkHealthStatus() {
  try {
    const health = await API.checkHealth();
    const statusEl = document.getElementById('serverStatusText');
    if (statusEl) {
      statusEl.textContent = 'Servidor Online';
    }
  } catch (err) {
    const statusEl = document.getElementById('serverStatusText');
    if (statusEl) {
      statusEl.textContent = 'Servidor Desconectado';
      statusEl.parentElement.style.color = '#f43f5e';
    }
  }
}

// Navegación entre pestañas
function setupTabNavigation() {
  const tabButtons = document.querySelectorAll('.tab-btn');
  tabButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      const targetTab = btn.getAttribute('data-tab');
      switchTab(targetTab);
    });
  });
}

function switchTab(tabId) {
  AppState.currentTab = tabId;

  document.querySelectorAll('.tab-btn').forEach((b) => {
    b.classList.toggle('active', b.getAttribute('data-tab') === tabId);
  });

  document.querySelectorAll('.tab-content').forEach((content) => {
    content.classList.toggle('active', content.id === `tab-${tabId}`);
  });

  if (tabId === 'reservas') {
    loadReservasTable();
  } else if (tabId === 'clientes') {
    loadClientesGrid();
  } else if (tabId === 'proveedores') {
    loadProveedoresView();
  }
}

// Configuración de fecha por defecto
function setupDateHelpers() {
  const dateInput = document.getElementById('inputFechaReserva');
  const today = new Date();
  
  // Establecer fecha por defecto a mañana o un día laboral
  const defaultDate = new Date(today);
  defaultDate.setDate(today.getDate() + 1);
  const yyyy = defaultDate.getFullYear();
  const mm = String(defaultDate.getMonth() + 1).padStart(2, '0');
  const dd = String(defaultDate.getDate()).padStart(2, '0');
  const defaultDateStr = `${yyyy}-${mm}-${dd}`;

  dateInput.value = defaultDateStr;
  AppState.selectedFecha = defaultDateStr;

  dateInput.addEventListener('change', (e) => {
    AppState.selectedFecha = e.target.value;
    loadAvailabilitySlots();
  });

  // Botones rápidos de fecha (Hoy, Mañana, En 2 días)
  document.querySelectorAll('.quick-date-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.quick-date-btn').forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');

      const offset = parseInt(btn.getAttribute('data-days-offset'), 10);
      const target = new Date();
      target.setDate(target.getDate() + offset);

      const tY = target.getFullYear();
      const tM = String(target.getMonth() + 1).padStart(2, '0');
      const tD = String(target.getDate()).padStart(2, '0');
      const dateStr = `${tY}-${tM}-${tD}`;

      dateInput.value = dateStr;
      AppState.selectedFecha = dateStr;
      loadAvailabilitySlots();
    });
  });
}

// Cargar datos iniciales
async function loadInitialData() {
  try {
    const [proveedores, clientes, reservas] = await Promise.all([
      API.proveedores.list(),
      API.clientes.list(),
      API.reservas.list()
    ]);

    AppState.proveedores = proveedores;
    AppState.clientes = clientes;
    AppState.reservas = reservas;

    updateHeaderStats();
    renderProviderOptions();
    populateClienteSelects();

    // Seleccionar el primer proveedor por defecto
    if (proveedores.length > 0) {
      selectProvider(proveedores[0].id);
    }
  } catch (err) {
    Toast.error('Error al inicializar', 'No se pudieron cargar los datos iniciales del servidor.');
  }
}

// Actualizar contadores del panel superior
function updateHeaderStats() {
  document.getElementById('statTotalProveedores').textContent = AppState.proveedores.length;
  document.getElementById('statTotalClientes').textContent = AppState.clientes.length;
  
  const confirmadas = AppState.reservas.filter((r) => r.estado === 'confirmada').length;
  document.getElementById('statTotalReservas').textContent = confirmadas;

  // Turnos para la fecha actual
  const todayIso = new Date().toISOString().slice(0, 10);
  const hoyCount = AppState.reservas.filter(
    (r) => r.fechaHoraInicio.startsWith(todayIso) && r.estado === 'confirmada'
  ).length;
  document.getElementById('statTurnosHoy').textContent = hoyCount;
}

// Renderizar opciones de proveedores en la pestaña de agendamiento
function renderProviderOptions() {
  const container = document.getElementById('providersSelectList');
  container.innerHTML = '';

  const diasNombres = { 1: 'Lun', 2: 'Mar', 3: 'Mié', 4: 'Jue', 5: 'Vie', 6: 'Sáb', 7: 'Dom' };

  AppState.proveedores.forEach((p) => {
    const diasArray = typeof p.diasAtencion === 'string' ? p.diasAtencion.split(',') : p.diasAtencion;
    const diasStr = diasArray.map((d) => diasNombres[d] || d).join(', ');

    const card = document.createElement('div');
    card.className = `provider-option-card ${p.id === AppState.selectedProveedorId ? 'selected' : ''}`;
    card.id = `provider-opt-${p.id}`;

    card.innerHTML = `
      <div class="provider-info-left">
        <div class="provider-name">${p.nombre}</div>
        <div class="provider-tags">
          <span class="badge badge-tipo">${p.tipo}</span>
          <span class="badge badge-duracion">${p.duracionMinutos} min / turno</span>
          <span class="badge badge-dias">Atención: ${p.horaApertura} - ${p.horaCierre} (${diasStr})</span>
        </div>
      </div>
      <div class="provider-check-icon">
        <svg width="20" height="20" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/></svg>
      </div>
    `;

    card.addEventListener('click', () => {
      selectProvider(p.id);
    });

    container.appendChild(card);
  });
}

function selectProvider(providerId) {
  AppState.selectedProveedorId = providerId;
  AppState.selectedSlot = null;

  document.querySelectorAll('.provider-option-card').forEach((c) => {
    c.classList.toggle('selected', c.id === `provider-opt-${providerId}`);
  });

  const proveedor = AppState.proveedores.find((p) => p.id === providerId);
  if (proveedor) {
    document.getElementById('summaryProveedorName').textContent = proveedor.nombre;
    document.getElementById('summaryDuracion').textContent = `${proveedor.duracionMinutos} minutos`;
  }

  hideConflictAlert();
  updateSummarySlot(null);
  loadAvailabilitySlots();
}

// Cargar intervalos de disponibilidad en tiempo real desde la API
async function loadAvailabilitySlots() {
  if (!AppState.selectedProveedorId || !AppState.selectedFecha) return;

  const container = document.getElementById('slotsGridContainer');
  const countBadge = document.getElementById('slotsCountBadge');
  const dateTitle = document.getElementById('slotsDateTitle');

  dateTitle.textContent = `Turnos del ${AppState.selectedFecha}`;
  container.innerHTML = `
    <div class="state-empty" style="grid-column: 1 / -1;">
      <div class="pulse-dot" style="margin: 0 auto 1rem;"></div>
      <p>Calculando disponibilidad en tiempo real...</p>
    </div>
  `;

  try {
    const data = await API.proveedores.disponibilidad(AppState.selectedProveedorId, AppState.selectedFecha);
    const slots = data.intervalosDisponibles || [];

    countBadge.textContent = `${slots.length} turnos disponibles`;

    if (slots.length === 0) {
      container.innerHTML = `
        <div class="state-empty" style="grid-column: 1 / -1;">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          <p><strong>No hay turnos disponibles para esta fecha.</strong></p>
          <p style="font-size: 0.85rem; margin-top: 4px;">El proveedor puede no laborar este día o tener todos sus turnos reservados.</p>
        </div>
      `;
      return;
    }

    container.innerHTML = '';
    slots.forEach((slot, idx) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'slot-btn';

      // Extraer hora local HH:MM del string ISO
      const inicioHora = slot.inicio.slice(11, 16);
      const finHora = slot.fin.slice(11, 16);

      btn.innerHTML = `
        <span class="slot-time">${inicioHora}</span>
        <span class="slot-end">Hasta ${finHora}</span>
      `;

      btn.addEventListener('click', () => {
        document.querySelectorAll('.slot-btn').forEach((b) => b.classList.remove('selected'));
        btn.classList.add('selected');
        AppState.selectedSlot = slot;
        updateSummarySlot(slot);
        hideConflictAlert();
      });

      container.appendChild(btn);
    });
  } catch (err) {
    countBadge.textContent = '0 turnos';
    container.innerHTML = `
      <div class="state-empty" style="grid-column: 1 / -1; color: #f43f5e;">
        <p><strong>${err.message || 'Error al consultar disponibilidad'}</strong></p>
      </div>
    `;
  }
}

function updateSummarySlot(slot) {
  const slotTextEl = document.getElementById('summarySlotTime');
  const confirmBtn = document.getElementById('btnConfirmarReserva');

  if (slot) {
    const inicio = slot.inicio.slice(11, 16);
    const fin = slot.fin.slice(11, 16);
    slotTextEl.textContent = `${inicio} a ${fin} (${AppState.selectedFecha})`;
    confirmBtn.disabled = false;
  } else {
    slotTextEl.textContent = 'Selecciona un turno';
    confirmBtn.disabled = true;
  }
}

// Población de desplegables de clientes
function populateClienteSelects() {
  const select = document.getElementById('selectClienteReserva');
  select.innerHTML = '<option value="">-- Selecciona un Cliente Registrado --</option>';

  AppState.clientes.forEach((c) => {
    const opt = document.createElement('option');
    opt.value = c.id;
    opt.textContent = `${c.nombre} (${c.email})`;
    select.appendChild(opt);
  });

  if (AppState.clientes.length > 0) {
    select.value = AppState.clientes[0].id;
    AppState.selectedClienteId = AppState.clientes[0].id;
  }

  select.addEventListener('change', (e) => {
    AppState.selectedClienteId = e.target.value ? Number(e.target.value) : null;
  });
}

// Configuración de listeners globales
function setupEventListeners() {
  // Confirmar Reserva
  document.getElementById('btnConfirmarReserva').addEventListener('click', handleConfirmarReserva);

  // Botón abrir modal nuevo cliente
  document.getElementById('btnOpenModalCliente').addEventListener('click', () => {
    resetClienteForm();
    Modal.open('modalCliente');
  });

  // Guardar Cliente (POST o PUT)
  document.getElementById('formCliente').addEventListener('submit', handleSaveCliente);

  // Filtros de Reservas
  document.getElementById('filterReservasProveedor').addEventListener('change', loadReservasTable);
  document.getElementById('filterReservasEstado').addEventListener('change', loadReservasTable);

  // Búsqueda en tabla de clientes
  document.getElementById('searchClientesInput').addEventListener('input', (e) => {
    filterClientesGrid(e.target.value);
  });
}

// Acción: Confirmar creación de Reserva
async function handleConfirmarReserva() {
  if (!AppState.selectedClienteId) {
    Toast.warning('Cliente requerido', 'Por favor selecciona o crea un cliente para agendar.');
    return;
  }

  if (!AppState.selectedProveedorId || !AppState.selectedSlot) {
    Toast.warning('Turno requerido', 'Por favor selecciona un proveedor y un turno disponible.');
    return;
  }

  const proveedor = AppState.proveedores.find((p) => p.id === AppState.selectedProveedorId);
  const confirmBtn = document.getElementById('btnConfirmarReserva');

  const reservaData = {
    clienteId: AppState.selectedClienteId,
    proveedorId: AppState.selectedProveedorId,
    fechaHoraInicio: AppState.selectedSlot.inicio,
    duracionMinutos: proveedor.duracionMinutos
  };

  confirmBtn.disabled = true;
  confirmBtn.textContent = 'Procesando reserva...';

  try {
    const response = await API.reservas.create(reservaData);
    Toast.success('¡Reserva Confirmada!', `Cita programada exitosamente para el ID #${response.id}.`);

    // Recargar turnos y reservas
    AppState.reservas = await API.reservas.list();
    updateHeaderStats();
    loadAvailabilitySlots();

    // Reset slot seleccionado
    AppState.selectedSlot = null;
    updateSummarySlot(null);
  } catch (err) {
    // Si es conflicto exacto de solapamiento (409)
    if (err.status === 409) {
      showConflictAlert(err.message || 'El proveedor ya tiene una reserva en el intervalo solicitado.');
      Toast.error('Conflicto de Horario', err.message);
      loadAvailabilitySlots(); // Actualizar slots para reflejar el horario ocupado
    } else {
      Toast.error('No se pudo reservar', err.message);
    }
  } finally {
    confirmBtn.disabled = false;
    confirmBtn.innerHTML = `
      <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
      Confirmar y Agendar Cita
    `;
  }
}

function showConflictAlert(msg) {
  const alertEl = document.getElementById('conflictAlertBanner');
  const textEl = document.getElementById('conflictAlertText');
  textEl.textContent = msg;
  alertEl.classList.add('show');
}

function hideConflictAlert() {
  const alertEl = document.getElementById('conflictAlertBanner');
  alertEl.classList.remove('show');
}

// ==========================================================================
// GESTIÓN DE RESERVAS
// ==========================================================================
async function loadReservasTable() {
  const tbody = document.getElementById('reservasTableBody');
  tbody.innerHTML = `<tr><td colspan="7" class="state-empty">Cargando reservas...</td></tr>`;

  try {
    const proveedorFilter = document.getElementById('filterReservasProveedor').value;
    const estadoFilter = document.getElementById('filterReservasEstado').value;

    const filters = {};
    if (proveedorFilter) filters.proveedorId = proveedorFilter;
    if (estadoFilter) filters.estado = estadoFilter;

    const reservas = await API.reservas.list(filters);
    AppState.reservas = reservas;
    updateHeaderStats();

    // Actualizar select de proveedores en filtros si está vacío
    const filterSelect = document.getElementById('filterReservasProveedor');
    if (filterSelect.options.length <= 1) {
      AppState.proveedores.forEach((p) => {
        const opt = document.createElement('option');
        opt.value = p.id;
        opt.textContent = p.nombre;
        filterSelect.appendChild(opt);
      });
    }

    if (reservas.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" class="state-empty">No se encontraron reservas con los filtros aplicados.</td></tr>`;
      return;
    }

    tbody.innerHTML = '';
    reservas.forEach((r) => {
      const tr = document.createElement('tr');

      // Formatear fecha y hora amigable
      const inicio = new Date(r.fechaHoraInicio);
      const fin = new Date(r.fechaHoraFin);
      const fechaStr = inicio.toLocaleDateString('es-CO', { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' });
      const horaStr = `${inicio.toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' })} - ${fin.toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' })}`;

      tr.innerHTML = `
        <td><strong>#${r.id}</strong></td>
        <td>
          <div class="client-avatar-cell">
            <div class="avatar-circle">${r.clienteNombre ? r.clienteNombre.slice(0, 2).toUpperCase() : 'CL'}</div>
            <div>
              <div style="font-weight: 600; color: white;">${r.clienteNombre}</div>
              <div style="font-size: 0.78rem; color: var(--text-dim);">${r.clienteEmail}</div>
            </div>
          </div>
        </td>
        <td>
          <div style="font-weight: 600; color: white;">${r.proveedorNombre}</div>
          <span class="badge badge-tipo" style="margin-top: 3px;">${r.proveedorTipo}</span>
        </td>
        <td>
          <div style="font-weight: 600; color: white;">${fechaStr}</div>
          <div style="font-size: 0.78rem; color: #a855f7;">${horaStr}</div>
        </td>
        <td>
          <span class="status-pill ${r.estado}">
            <span class="pulse-dot" style="background-color: currentColor; box-shadow: none;"></span>
            ${r.estado}
          </span>
        </td>
        <td>
          <div class="action-btns">
            ${
              r.estado === 'confirmada'
                ? `<button class="btn-icon cancel" title="Cancelar Reserva (libera horario)" onclick="cancelarReservaClick(${r.id})">
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                   </button>`
                : ''
            }
            <button class="btn-icon delete" title="Eliminar definitivamente" onclick="eliminarReservaClick(${r.id})">
              <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
            </button>
          </div>
        </td>
      `;

      tbody.appendChild(tr);
    });
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="7" class="state-empty" style="color: #f43f5e;">Error: ${err.message}</td></tr>`;
  }
}

window.cancelarReservaClick = async function (id) {
  if (!confirm(`¿Deseas cancelar la reserva #${id}? El horario asignado quedará libre para nuevos turnos.`)) {
    return;
  }

  try {
    await API.reservas.cancel(id);
    Toast.success('Reserva Cancelada', `La reserva #${id} ha sido cancelada y su horario fue liberado.`);
    loadReservasTable();
    loadAvailabilitySlots();
  } catch (err) {
    Toast.error('Error al cancelar', err.message);
  }
};

window.eliminarReservaClick = async function (id) {
  if (!confirm(`¿Estás seguro de eliminar permanentemente el registro de la reserva #${id}?`)) {
    return;
  }

  try {
    await API.reservas.delete(id);
    Toast.success('Reserva Eliminada', `La reserva #${id} fue eliminada de la base de datos.`);
    loadReservasTable();
    loadAvailabilitySlots();
  } catch (err) {
    Toast.error('Error al eliminar', err.message);
  }
};

// ==========================================================================
// DIRECTORIO DE CLIENTES
// ==========================================================================
async function loadClientesGrid() {
  try {
    AppState.clientes = await API.clientes.list();
    filterClientesGrid('');
  } catch (err) {
    Toast.error('Error al cargar clientes', err.message);
  }
}

function filterClientesGrid(query) {
  const container = document.getElementById('clientesGridContainer');
  const q = query.trim().toLowerCase();

  const filtered = AppState.clientes.filter(
    (c) => c.nombre.toLowerCase().includes(q) || c.email.toLowerCase().includes(q) || (c.telefono && c.telefono.includes(q))
  );

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="state-empty" style="grid-column: 1 / -1;">
        <p>No se encontraron clientes que coincidan con la búsqueda.</p>
      </div>
    `;
    return;
  }

  container.innerHTML = '';
  filtered.forEach((c) => {
    const card = document.createElement('div');
    card.className = 'glass-panel';
    card.style.padding = '1.35rem';

    card.innerHTML = `
      <div style="display: flex; align-items: flex-start; justify-content: space-between; margin-bottom: 1rem;">
        <div class="client-avatar-cell">
          <div class="avatar-circle" style="width: 44px; height: 44px; font-size: 1rem;">${c.nombre.slice(0, 2).toUpperCase()}</div>
          <div>
            <h4 style="font-family: var(--font-heading); font-size: 1.05rem; font-weight: 700; color: white;">${c.nombre}</h4>
            <span style="font-size: 0.78rem; color: #a855f7; font-weight: 600;">ID #${c.id}</span>
          </div>
        </div>
        <div class="action-btns">
          <button class="btn-icon edit" title="Editar datos" onclick="editClienteClick(${c.id})">
            <svg width="15" height="15" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"/></svg>
          </button>
          <button class="btn-icon delete" title="Eliminar cliente" onclick="deleteClienteClick(${c.id})">
            <svg width="15" height="15" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
          </button>
        </div>
      </div>
      <div style="display: flex; flex-direction: column; gap: 0.4rem; font-size: 0.85rem; color: var(--text-muted);">
        <div style="display: flex; align-items: center; gap: 0.5rem;">
          <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
          <span style="color: white;">${c.email}</span>
        </div>
        <div style="display: flex; align-items: center; gap: 0.5rem;">
          <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
          <span>${c.telefono || 'Sin teléfono'}</span>
        </div>
      </div>
    `;

    container.appendChild(card);
  });
}

function resetClienteForm() {
  document.getElementById('formClienteId').value = '';
  document.getElementById('inputClienteNombre').value = '';
  document.getElementById('inputClienteEmail').value = '';
  document.getElementById('inputClienteTelefono').value = '';
  document.getElementById('modalClienteTitle').textContent = 'Registrar Nuevo Cliente';
}

window.editClienteClick = function (id) {
  const cliente = AppState.clientes.find((c) => c.id === id);
  if (!cliente) return;

  document.getElementById('formClienteId').value = cliente.id;
  document.getElementById('inputClienteNombre').value = cliente.nombre;
  document.getElementById('inputClienteEmail').value = cliente.email;
  document.getElementById('inputClienteTelefono').value = cliente.telefono || '';
  document.getElementById('modalClienteTitle').textContent = `Editar Cliente #${cliente.id}`;

  Modal.open('modalCliente');
};

window.deleteClienteClick = async function (id) {
  if (!confirm(`¿Eliminar al cliente #${id}? Si tiene reservas asociadas, el sistema impedirá su borrado.`)) {
    return;
  }

  try {
    await API.clientes.delete(id);
    Toast.success('Cliente Eliminado', `El cliente #${id} fue eliminado correctamente.`);
    loadClientesGrid();
    populateClienteSelects();
    updateHeaderStats();
  } catch (err) {
    Toast.error('No se pudo eliminar', err.message);
  }
};

async function handleSaveCliente(e) {
  e.preventDefault();

  const id = document.getElementById('formClienteId').value;
  const nombre = document.getElementById('inputClienteNombre').value.trim();
  const email = document.getElementById('inputClienteEmail').value.trim();
  const telefono = document.getElementById('inputClienteTelefono').value.trim();

  const payload = {
    nombre,
    email,
    telefono: telefono || null
  };

  try {
    if (id) {
      // PUT
      const updated = await API.clientes.update(id, payload);
      Toast.success('Cliente Actualizado', `Los datos de ${updated.nombre} se guardaron exitosamente.`);
    } else {
      // POST
      const nuevo = await API.clientes.create(payload);
      Toast.success('Cliente Creado', `Se registró a ${nuevo.nombre} con ID #${nuevo.id}.`);
    }

    Modal.close('modalCliente');
    loadClientesGrid();
    populateClienteSelects();
    updateHeaderStats();
  } catch (err) {
    Toast.error('Error al guardar cliente', err.message);
  }
}

// ==========================================================================
// PROVEEDORES VIEW
// ==========================================================================
function loadProveedoresView() {
  const container = document.getElementById('proveedoresCardsGrid');
  container.innerHTML = '';

  const diasNombres = { 1: 'Lunes', 2: 'Martes', 3: 'Miércoles', 4: 'Jueves', 5: 'Viernes', 6: 'Sábado', 7: 'Domingo' };

  AppState.proveedores.forEach((p) => {
    const card = document.createElement('div');
    card.className = 'glass-panel';
    card.style.display = 'flex';
    card.style.flexDirection = 'column';
    card.style.justifyContent = 'space-between';

    const diasArray = typeof p.diasAtencion === 'string' ? p.diasAtencion.split(',') : p.diasAtencion;
    const diasStr = diasArray.map((d) => diasNombres[d] || d).join(', ');

    card.innerHTML = `
      <div>
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.8rem;">
          <span class="badge badge-tipo">${p.tipo}</span>
          <span class="status-pill confirmada" style="font-size: 0.7rem;">Activo</span>
        </div>
        <h3 style="font-family: var(--font-heading); font-size: 1.25rem; font-weight: 700; color: white; margin-bottom: 0.75rem;">
          ${p.nombre}
        </h3>
        <div style="display: flex; flex-direction: column; gap: 0.45rem; font-size: 0.88rem; color: var(--text-muted); margin-bottom: 1.5rem;">
          <div style="display: flex; align-items: center; gap: 0.5rem;">
            <svg width="16" height="16" fill="none" stroke="#a855f7" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            <span>Horario: <strong style="color: white;">${p.horaApertura} - ${p.horaCierre}</strong></span>
          </div>
          <div style="display: flex; align-items: center; gap: 0.5rem;">
            <svg width="16" height="16" fill="none" stroke="#22d3ee" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
            <span>Duración por turno: <strong style="color: white;">${p.duracionMinutos} min</strong></span>
          </div>
          <div style="display: flex; align-items: center; gap: 0.5rem;">
            <svg width="16" height="16" fill="none" stroke="#34d399" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
            <span>Días: <strong style="color: white;">${diasStr}</strong></span>
          </div>
        </div>
      </div>
      <button class="btn-action" style="width: 100%; display: flex; align-items: center; justify-content: center; gap: 0.5rem;" onclick="agendarConProveedor(${p.id})">
        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
        Agendar Turno Aquí
      </button>
    `;

    container.appendChild(card);
  });
}

window.agendarConProveedor = function (id) {
  switchTab('agenda');
  selectProvider(id);
};
