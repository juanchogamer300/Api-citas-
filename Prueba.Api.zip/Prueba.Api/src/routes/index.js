const { Router } = require('express');
const createClienteRoutes = require('./clienteRoutes');
const createProveedorRoutes = require('./proveedorRoutes');
const createReservaRoutes = require('./reservaRoutes');

function createApiRouter(services = {}) {
  const router = Router();

  router.use('/clientes', createClienteRoutes(services.clienteService));
  router.use('/proveedores', createProveedorRoutes(services.proveedorService));
  router.use('/reservas', createReservaRoutes(services.reservaService));

  return router;
}

module.exports = createApiRouter;
