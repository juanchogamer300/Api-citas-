const { getDatabase } = require('./connection');
const { initSchema } = require('./schema');

/**
 * Inserta datos de prueba reproducibles sin duplicar registros en arranques sucesivos.
 * @param {import('better-sqlite3').Database} [targetDb]
 */
function seedDatabase(targetDb) {
  const db = targetDb || getDatabase();
  initSchema(db);

  const insertCliente = db.prepare(`
    INSERT INTO clientes (id, nombre, email, telefono)
    VALUES (?, ?, ?, ?)
    ON CONFLICT(email) DO UPDATE SET
      nombre = excluded.nombre,
      telefono = excluded.telefono
  `);

  const initialClientes = [
    [1, 'Carlos Gómez', 'carlos.gomez@email.com', '+573001112233'],
    [2, 'Laura Restrepo', 'laura.restrepo@email.com', '+573004445566'],
    [3, 'Andrés Moreno', 'andres.moreno@email.com', '+573007778899']
  ];

  const insertProveedor = db.prepare(`
    INSERT INTO proveedores (id, nombre, tipo, duracionMinutos, horaApertura, horaCierre, diasAtencion, activo)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      nombre = excluded.nombre,
      tipo = excluded.tipo,
      duracionMinutos = excluded.duracionMinutos,
      horaApertura = excluded.horaApertura,
      horaCierre = excluded.horaCierre,
      diasAtencion = excluded.diasAtencion,
      activo = excluded.activo
  `);

  const initialProveedores = [
    [
      1,
      'Dra. Sofía Martínez - Consulta General',
      'Salud',
      30,
      '08:00',
      '17:00',
      '1,2,3,4,5',
      1
    ],
    [
      2,
      'Barbería King - Corte y Barba',
      'Estética',
      45,
      '09:00',
      '19:00',
      '1,2,3,4,5,6',
      1
    ],
    [
      3,
      'Cancha Sintética El Golazo - Cancha 5',
      'Deportes',
      60,
      '07:00',
      '22:00',
      '1,2,3,4,5,6,7',
      1
    ]
  ];

  const seedTransaction = db.transaction(() => {
    for (const c of initialClientes) {
      insertCliente.run(...c);
    }
    for (const p of initialProveedores) {
      insertProveedor.run(...p);
    }
  });

  seedTransaction();
}

if (require.main === module) {
  const db = getDatabase();
  seedDatabase(db);
  console.log('Base de datos inicializada y poblada con datos reproducibles exitosamente.');
  process.exit(0);
}

module.exports = {
  seedDatabase
};
