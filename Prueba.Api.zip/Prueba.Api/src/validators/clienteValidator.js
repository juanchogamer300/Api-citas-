const { BadRequestError } = require('../utils/errors');

function validateCreateCliente(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    throw new BadRequestError('El cuerpo de la solicitud debe ser un objeto JSON válido.');
  }

  const { nombre, email, telefono } = body;

  if (!nombre || typeof nombre !== 'string' || !nombre.trim()) {
    throw new BadRequestError("El campo 'nombre' es obligatorio y debe ser un texto no vacío.");
  }

  if (nombre.trim().length < 2 || nombre.trim().length > 100) {
    throw new BadRequestError("El campo 'nombre' debe tener entre 2 y 100 caracteres.");
  }

  if (!email || typeof email !== 'string' || !email.trim()) {
    throw new BadRequestError("El campo 'email' es obligatorio.");
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email.trim())) {
    throw new BadRequestError("El campo 'email' no contiene una dirección de correo electrónico válida.");
  }

  if (telefono !== undefined && telefono !== null) {
    if (typeof telefono !== 'string' || !telefono.trim()) {
      throw new BadRequestError("El campo 'telefono' debe ser un texto si se proporciona.");
    }
    if (telefono.trim().length < 5 || telefono.trim().length > 30) {
      throw new BadRequestError("El campo 'telefono' debe tener entre 5 y 30 caracteres.");
    }
  }

  return {
    nombre: nombre.trim(),
    email: email.trim().toLowerCase(),
    telefono: telefono ? telefono.trim() : null
  };
}

function validateIdParam(idParam, entityName = 'recurso') {
  const id = Number(idParam);
  if (!Number.isInteger(id) || id <= 0) {
    throw new BadRequestError(`El identificador de ${entityName} debe ser un número entero positivo.`);
  }
  return id;
}

function validateUpdateCliente(body) {
  return validateCreateCliente(body);
}

module.exports = {
  validateCreateCliente,
  validateUpdateCliente,
  validateIdParam
};

