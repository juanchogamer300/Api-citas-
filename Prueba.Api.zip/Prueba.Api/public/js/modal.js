/**
 * Sistema de Ventanas Modales Interactivas
 */
const Modal = {
  activeModal: null,

  open(modalId) {
    const modal = document.getElementById(modalId);
    if (!modal) return;

    this.activeModal = modal;
    modal.classList.add('open');
    document.body.style.overflow = 'hidden';
  },

  close(modalId) {
    const modal = modalId ? document.getElementById(modalId) : this.activeModal;
    if (!modal) return;

    modal.classList.remove('open');
    document.body.style.overflow = '';
    this.activeModal = null;
  },

  init() {
    // Escuchar clics fuera de la ventana modal para cerrar
    document.querySelectorAll('.modal-backdrop').forEach((backdrop) => {
      backdrop.addEventListener('click', (e) => {
        if (e.target === backdrop) {
          this.close(backdrop.id);
        }
      });
    });

    // Escuchar tecla ESC
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.activeModal) {
        this.close();
      }
    });

    // Botones con data-close-modal
    document.querySelectorAll('[data-close-modal]').forEach((btn) => {
      btn.addEventListener('click', () => {
        this.close();
      });
    });
  }
};

window.Modal = Modal;
