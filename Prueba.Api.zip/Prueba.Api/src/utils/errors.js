class AppError extends Error {
  constructor(message, statusCode = 500, detalle = null) {
    super(message);
    this.name = this.constructor.name;
    this.statusCode = statusCode;
    this.detalle = detalle || message;
    Error.captureStackTrace(this, this.constructor);
  }
}

class BadRequestError extends AppError {
  constructor(detalle = 'Datos inválidos en la solicitud') {
    super('Solicitud inválida', 400, detalle);
  }
}

class NotFoundError extends AppError {
  constructor(detalle = 'Recurso no encontrado') {
    super('Recurso no encontrado', 404, detalle);
  }
}

class ConflictError extends AppError {
  constructor(detalle = 'Conflicto con el estado actual del recurso', errorTitle = 'Conflicto') {
    super(errorTitle, 409, detalle);
  }
}

/**
 * Error obligatorio y exacto para solapamientos de horario según especificación:
 * HTTP 409
 * {
 *   "error": "Conflicto de horario",
 *   "detalle": "El proveedor ya tiene una reserva en el intervalo solicitado."
 * }
 */
class ScheduleConflictError extends AppError {
  constructor() {
    super(
      'Conflicto de horario',
      409,
      'El proveedor ya tiene una reserva en el intervalo solicitado.'
    );
    this.isScheduleConflict = true;
  }
}

module.exports = {
  AppError,
  BadRequestError,
  NotFoundError,
  ConflictError,
  ScheduleConflictError
};
