const ProveedorService = require('../services/proveedorService');
const { validateProveedorId, validateDisponibilidadQuery } = require('../validators/proveedorValidator');

class ProveedorController {
  constructor(proveedorService) {
    this.proveedorService = proveedorService || new ProveedorService();
  }

  listarProveedores = async (req, res, next) => {
    try {
      const proveedores = this.proveedorService.obtenerActivos();
      return res.status(200).json(proveedores);
    } catch (error) {
      next(error);
    }
  };

  obtenerProveedorPorId = async (req, res, next) => {
    try {
      const id = validateProveedorId(req.params.id);
      const proveedor = this.proveedorService.obtenerPorId(id);
      return res.status(200).json(proveedor);
    } catch (error) {
      next(error);
    }
  };

  obtenerDisponibilidad = async (req, res, next) => {
    try {
      const id = validateProveedorId(req.params.id);
      const { fecha } = validateDisponibilidadQuery(req.query);
      const disponibilidad = this.proveedorService.obtenerDisponibilidad(id, fecha);
      return res.status(200).json(disponibilidad);
    } catch (error) {
      next(error);
    }
  };
}

module.exports = ProveedorController;
